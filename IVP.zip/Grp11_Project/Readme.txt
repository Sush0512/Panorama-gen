Input images for code grp11_1.py: ## Demonstrates stitching and blending
1. 1Hill.JPG, 2Hill.JPG
2. S1.jpg, S2.jpg
3. l1.png, r1.png

Input images for code grp11_2.py  ## Demonstrates deghosting 
1. f1.png, f2. png ## Written in code

## Sample for demonstration
img = cv2.imread('S1.jpg') # Reading image 1
img1= cv2.imread('S2.jpg') # Reading image 2

## To run

1.python grp11_1.py
Output: 2 images 
a) Mosaic without seam removal
b) Mosaic with seam removal

2.python grp11_2.py
Output: 2 images
a)Illustration of ghosting
b)Deghosting
