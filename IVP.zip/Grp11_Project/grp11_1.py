import cv2
import numpy as np
import time
img = cv2.imread('S1.jpg') # Reading image 1

img1= cv2.imread('S2.jpg') # Reading image 2
print(np.shape(img))


start_time = time.time() # Starting the time module to find the time taken for execution of code


gray1= cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)# Converting from rgb to grey scale
gray2= cv2.cvtColor(img1,cv2.COLOR_BGR2GRAY)

sift = cv2.xfeatures2d.SIFT_create()

kp1, des1 = sift.detectAndCompute(gray1,None) #Keypoints n descriptors of the first image
kp2, des2 = sift.detectAndCompute(gray2,None) #Keypoints n descriptors of the second image


# FLANN parameters
FLANN_INDEX_KDTREE = 0
index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)  #Algorthim passed - KD TEREE
search_params = dict(checks=50)   # or pass empty dictionary

flann = cv2.FlannBasedMatcher(index_params,search_params)

matches = flann.knnMatch(des1,des2,k=2) #finding 2 nearest neighbours

# store all the good matches as per Lowe's ratio test.
good = []
for m,n in matches:
    if m.distance < 0.7*n.distance:
        good.append(m)



MIN_MATCH_COUNT=10
if len(good)>MIN_MATCH_COUNT:
    src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)  #Source points
    dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)	#Destination points

    M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,4.0)## finding the homography matrix using RANSAC
    matchesMask = mask.ravel().tolist()
    #print(M)
    M=np.linalg.inv(M)
    result = cv2.warpPerspective(img1, M,(img.shape[1] + img1.shape[1], img.shape[0])) ##transforms the image
    h,w = np.shape(gray2)
    #print(h,w) 
   
    result1=np.array(result)
    result[0:img.shape[0], 0:img.shape[1]] = img
    cv2.imshow("Stitched mosaic with seams",result)
    cv2.waitKey()
    ##################################Seam Removal###################################
    
    
    n=150
    alpha=[0 for i in range(n)] # Initializing weights array
    d=1/float(n)
    alpha[0]=1
    for i in range(1,n):
      alpha[i]= alpha[i-1]-d  # Weights varying in steps of 1/n from left to right in the overlapping region
    for j in range(w-n,w):
      for i in range(h):      # Weighted average of intensities in overlapping region, for all 3 rgb components 
        alpha[j-(w-n)]=(alpha[j-(w-n)])
        img[i,j][0]= alpha[j-(w-n)]*img[i,j][0]+(1-alpha[j-(w-n)])*result1[i,j][0]
        img[i,j][1]= alpha[j-(w-n)]*img[i,j][1]+(1-alpha[j-(w-n)])*result1[i,j][1]
        img[i,j][2]= alpha[j-(w-n)]*img[i,j][2]+(1-alpha[j-(w-n)])*result1[i,j][2]  
   
    result1[0:img.shape[0], 0:img.shape[1]] = img
   
else:
    print("Not enough matches are found - %d,%d" % (len(good),MIN_MATCH_COUNT))
    matchesMask = None
  
print("--- %s seconds ---" % (time.time() - start_time))

cv2.imshow("Blended mosaic",result1)
cv2.waitKey()
